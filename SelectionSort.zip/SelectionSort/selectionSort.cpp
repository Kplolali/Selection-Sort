#include<iostream>  
//10661022

using namespace std;  
int findSmallest (int[],int);  
int main ()  
{  
    int array[12] = {3,5,27,0,42,253,123,14,101,22,45,12};  
    int pos,temp;  
    cout<<"\n Input list of elements to be Sorted\n";  
    for(int i=0;i<10;i++)  
    {  
        cout<<array[i]<<"\t";  
    } 
    for(int i=0;i<10;i++)  
    {  
        pos = findSmallest (array,i);  
        temp = array[i];  
        array[i]=array[pos];  
        array[pos] = temp; 
    }  
    cout<<"\n Sorted list of elements is\n";  
    for(int i=0;i<10;i++)  
    {  
        cout<<array[i]<<"\t";  
    } 

    return 0;  
}  
int findSmallest(int array[],int i)  
{  
    int small,position,j;  
    small = array[i];  
    position = i;  
    for(j=i+1;j<10;j++)  
    {  
        if(array[j]<small)  
        {  
            small = array[j];  
            position=j;  
        }  
    }  
    return position;  
}  


